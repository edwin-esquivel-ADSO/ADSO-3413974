# Dominio

> Estado: 🟡 | Última actualización: 2026-04-11
> Autor: Equipo 3

## Contenido

Esta carpeta contiene la representación conceptual del dominio del "Sistema de Gestión Comercial — Supermercado La Esquina" según SRS v1.0: mapa de dominios, entidades principales, invariantes y eventos de dominio. Es una descripción de negocio destinada a guiar el diseño técnico.

**Diferencia con `06-data`:** el contenido aquí es conceptual (entidades y reglas de negocio). Los detalles físicos de persistencia (tablas, columnas, esquemas) se documentan en `06-data/`.

## Archivos

| Archivo | Descripción | Estado |
|---------|-------------|--------|
| [domain-map.md](./domain-map.md) | Mapa de dominio y contextos principales (Ventas, Inventario, Proveedores, Reportes, Seguridad) | 🟡 |
| [entities-and-rules.md](./entities-and-rules.md) | Entidades, invariantes y reglas de negocio derivadas del SRS | 🟡 |
| [domain-events.md](./domain-events.md) | Eventos de dominio y significado funcional | 🟡 |

## Auditoría rápida

- Todos los artefactos de esta carpeta fueron actualizados para reflejar fielmente el SRS v1.0. Donde el SRS no provee detalles (tipos, formatos, contratos de eventos) se ha indicado "Pendiente de definición por el equipo de arquitectura".
