# domain-map

> Estado: 🟡 | Última actualización: 2026-04-11
> Autor: Equipo 3

## Propósito

El mapa de dominio identifica los contextos y límites principales del sistema según el SRS v1.0. Sirve como guía para el diseño por capas y la separación de responsabilidades.

## Contextos principales (bounded contexts)

- Punto de Venta (Ventas)
	- Responsabilidades: registro de ventas, cálculo de totales y cambio, generación de tickets, emisión del evento `VentaRegistrada`.

- Gestión de Inventario
	- Responsabilidades: mantenimiento del stock por producto, actualización automática al registrar ventas o recepciones, alertas de stock mínimo (`StockMinimoAlcanzado`).

- Proveedores y Compras
	- Responsabilidades: registro de proveedores, creación y seguimiento de pedidos, confirmación de recepción, integración con inventario.

- Reportes y Cierres
	- Responsabilidades: generación de cierre de día, resúmenes de ventas, top productos, exportación/imprenta de reportes, y copia de seguridad automática durante el cierre.

- Seguridad y Acceso
	- Responsabilidades: autenticación de usuarios y control de acceso por roles (Administrador, Cajero).

## Interacciones entre contextos

- El contexto Ventas emite `VentaRegistrada` que consume Inventario para decrementar stock y Reportes para actualizar métricas.
- Proveedores/Compras al confirmar recepción emite `RecepcionConfirmada` que actualiza Inventario.
- El cierre de día compila datos desde Ventas e Inventario y genera `CierreDelDiaGenerado` y `CopiaSeguridadCreada`.

## Observaciones

- El SRS define el alcance funcional (ventas, inventario, proveedores, reportes, autenticación). No hay mención a servicios externos ni microservicios: el diseño por bounded contexts se mantiene conceptual y orientado a una aplicación de escritorio monolítica por la versión 1.0.
- Detalles de integración, contratos y formatos de mensajes quedan pendientes de definición por el equipo de arquitectura.
