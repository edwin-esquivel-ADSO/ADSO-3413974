# entities-and-rules

> Estado: 🟡 | Última actualización: 2026-04-11
> Autor: Equipo 3

## Propósito

Descrbir las entidades principales, sus atributos más relevantes e invariantes/reglas de negocio derivadas del SRS v1.0. Esta sección es conceptual y no incluye el detalle físico de la base de datos (eso va en `06-data`).

## Entidades principales

- `Producto`
	- Atributos (resumen): `productoId`, `codigo`, `nombre`, `descripcion` (opcional), `precioVenta`, `stockActual`, `stockMinimo`.
	- Invariantes / reglas: `precioVenta >= 0`; `stockActual >= 0`.

- `Venta` (transacción)
	- Atributos: `ventaId`, `fechaHora`, `items` (lista de `VentaItem`), `total`, `idCajero`.
	- Regla: El `total` debe ser la suma de (cantidad * precioUnitario) por cada `VentaItem`.

- `VentaItem`
	- Atributos: `productoId`, `cantidad`, `precioUnitario`, `subtotal`.
	- Regla: `subtotal = cantidad * precioUnitario`.

- `Proveedor`
	- Atributos: `proveedorId`, `nombre`, `nit`, `telefono`, `email`, `condicionesPago`.
	- Regla: `nit` único por proveedor (evitar duplicados).

- `Pedido` (a proveedor)
	- Atributos: `pedidoId`, `proveedorId`, `items[(productoId,cantidadSolicitada)]`, `fechaCreacion`, `fechaEsperada`, `estado` (Pendiente, Recibido, Cancelado).
	- Regla: Al confirmar recepción (`estado`->Recibido) se actualiza `stockActual` de los `Producto` correspondientes.

- `Usuario` (para control de acceso)
	- Atributos: `usuarioId`, `nombre`, `usuario`, `hashPassword`, `rol` (Administrador | Cajero).
	- Regla: `rol` determina permisos; al menos un `Administrador` debe existir para operaciones de cierre de día y configuración.

## Reglas de negocio e invariantes globales

- Registro de ventas: cada venta genera decremento inmediato de `stockActual` por producto vendido.
- Alertas de inventario: cuando `stockActual <= stockMinimo` se genera un evento `StockMinimoAlcanzado` y aparece en los reportes del administrador.
- Un proveedor no debe duplicarse por `nit` o `nombre` idéntico sin confirmación manual (ver SRS: detección de duplicados).
- Cierre de día: acción del `Administrador` que genera resumen de ventas y copia de seguridad; si no hay ventas, se crea la copia de seguridad pero no el reporte de ventas (según flujo SRS).

## Observaciones y pendientes

- Tipos exactos, longitudes y formatos de identificadores y atributos no están especificados en SRS: Pendiente de definición por el equipo de arquitectura.
- Reglas adicionales de integridad (ej. transacciones, rollback al fallar actualización de inventario) deben definirse en la etapa de diseño técnico.
