# domain-events

> Estado: 🟡 | Última actualización: 2026-04-11
> Autor: Equipo 3

## Introducción

Este documento describe los eventos de dominio relevantes para el "Sistema de Gestión Comercial — Supermercado La Esquina". Los eventos representan sucesos de negocio significativos que otras partes del sistema pueden consumir (auditoría, reportes, sincronización, backups).

> Fuente: SRS v1.0 — Sistema de Gestión Comercial (Supermercado La Esquina).

## Lista de eventos de dominio

- `VentaRegistrada` (SaleRegistered)
	- Descripción: Se genera cuando se confirma una transacción de venta en el punto de venta.
	- Datos relevantes (resumen): idVenta, fechaHora, items[(productoId, cantidad, precioUnitario)], total, idCajero.
	- Efectos: Actualización de `Inventario` (disminución por producto), registro en historial de ventas.

- `InventarioActualizado` (InventoryUpdated)
	- Descripción: Se genera cuando cambia el stock de un producto (por venta, recepción de pedido o ajuste).
	- Datos: productoId, cantidadAnterior, cantidadNueva, motivo (venta|recepcion|ajuste), referenciaId (ventaId/pedidoId).

- `ProveedorRegistrado` (ProviderRegistered)
	- Descripción: Se emite al crear un nuevo proveedor en el directorio.
	- Datos: proveedorId, nombre, nit, contacto.

- `PedidoCreado` (OrderCreated)
	- Descripción: Se registra al generar un pedido a proveedor.
	- Datos: pedidoId, proveedorId, items[(productoId,cantidad)], fechaEsperada, estado=Pendiente.

- `RecepcionConfirmada` (ReceptionConfirmed)
	- Descripción: Se emite al confirmar la recepción de mercancía asociada a un pedido; actualiza inventario.
	- Datos: pedidoId, proveedorId, itemsRecibidos[(productoId,cantidad)], fechaRecepcion.

- `StockMinimoAlcanzado` (StockLow)
	- Descripción: Evento de alerta cuando el stock de un producto alcanza o desciende por debajo del umbral mínimo configurado.
	- Datos: productoId, cantidadActual, umbralMinimo.

- `CierreDelDiaGenerado` (DayCloseGenerated)
	- Descripción: Se genera al ejecutar el cierre de día; contiene resumen de ventas y métricas.
	- Datos: fecha, totalVentas, numeroTransacciones, ticketPromedio, topProductos, productosAgotados, saldoCajaEsperado.

- `CopiaSeguridadCreada` (BackupCreated)
	- Descripción: Indica que el sistema generó una copia de seguridad automática durante el cierre de día.
	- Datos: fecha, ubicacionArchivo (si aplica), resultado (exito|error).

## Observaciones

- Los esquemas completos de cada evento (tipos, longitudes, formatos) no están especificados en el SRS: Pendiente de definición por el equipo de arquitectura.
- El alcance expresado en SRS v1.0 limita integraciones externas; por tanto, los eventos se diseñan primero para uso local/sobre el sistema de escritorio.
