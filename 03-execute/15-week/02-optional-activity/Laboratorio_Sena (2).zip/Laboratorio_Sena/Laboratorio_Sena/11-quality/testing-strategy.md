# testing-strategy

> Estado: 🟡 | Última actualización: 2026-04-11
> Autor: Equipo 3

## Objetivo

Definir la estrategia de pruebas para la versión 1.0, centrada en lógica de negocio crítica y migraciones de datos.

## Niveles de prueba

- Unitarias: validar reglas del dominio (`02-domain`) — precios, cálculos de subtotales, validaciones de inventario.
- Integración: flujos críticos — registro de venta completo (creación de `Venta` + `VentaItem` + decremento de `stockActual`).
- End-to-end: pruebas en entorno que simule el punto de venta con DB local y operaciones de cierre de día.
- Regresión: ejecutar suite completa antes de publicar instalador.

## Cobertura y criterios

- Cobertura objetivo mínima para lógica de negocio: 80% (sujeto a revisión).
- Todas las migraciones deben tener pruebas de migración y reversión en entorno `staging`.

## Herramientas sugeridas

- Pytest para pruebas unitarias/integración.
- Fixtures que simulen DB local (SQLite) para pruebas automatizadas.

## Observaciones

- Dado que la app es de escritorio, se recomienda automatizar pruebas de integración al nivel de servicios/local processes donde sea posible; pruebas UI quedan como alcance futuro.
