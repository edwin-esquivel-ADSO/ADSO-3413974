# Calidad

> Estado: 🟡 | Última actualización: 2026-04-11
> Autor: Equipo 3

Define prácticas de pruebas, revisión de código y criterios de calidad. La prioridad para v1.0 es garantizar integridad de datos y fiabilidad de operaciones críticas (ventas, actualizaciones de inventario, migraciones).

## Archivos

| Archivo | Descripción | Estado |
|---------|-------------|--------|
| [testing-strategy.md](./testing-strategy.md) | Estrategia de pruebas por nivel y tipo | 🟡 |
| [code-review.md](./code-review.md) | Criterios y flujo para revisiones de código | 🟡 |

Notas: incluir pruebas unitarias para lógica de dominio y pruebas de integración para procesos de venta y migración de datos.
