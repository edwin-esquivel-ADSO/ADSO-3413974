# code-review

> Estado: 🟡 | Última actualización: 2026-04-11
> Autor: Equipo 3

## Propósito

Establecer criterios mínimos para revisiones de código: mantener calidad, detección temprana de errores y consistencia de estilo.

## Flujo recomendado

1. Pull Request con descripción del cambio y tickets relacionados.
2. Al menos una revisión aprobatoria de otro desarrollador.
3. Ejecutar pipelines de `test` y `build` antes de merge.

## Criterios de revisión

- Correctitud funcional y pruebas unitarias que cubran el cambio.
- No introducir secretos en el repositorio.
- Cumplimiento de convenciones de estilo (linters).
- Documentación actualizada si hay cambios en contratos o modelos de datos.

## Observaciones

- Para la v1.0 priorizar revisiones sobre cambios en el dominio y en migraciones de datos.
