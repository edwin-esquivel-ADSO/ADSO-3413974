# navigation-map

> Estado: 🟡 | Última actualización: 2026-04-11
> Autor: Equipo 3

## Mapa de pantallas (alto nivel)

1. `Login` — autenticación de usuario (Administrador, Cajero).
2. `POS / Punto de venta` — pantalla principal para registrar ventas.
3. `Inventario` — consultar y editar stock, alertas de stock mínimo.
4. `Proveedores y Pedidos` — crear/consultar pedidos a proveedores y recepciones.
5. `Reportes` — generar reportes diarios, ventas por rango y exportes.
6. `Administración` — gestión de usuarios, parámetros del sistema.

## Flujo típico (venta)

- Login → POS → Buscar producto → Agregar a carrito → Cobrar → Confirmación → Actualización de inventario → `CierreDelDia` opcional.

## Observaciones

- Detalles de navegación (side menu, tabs, atajos de teclado) deben definirse en wireframes y validados con usuarios finales.
