# design-system

> Estado: 🟡 | Última actualización: 2026-04-11
> Autor: Equipo 3

## Principios

- Interfaz clara y sin distracciones para operaciones de punto de venta.
- Elementos grandes y legibles para uso rápido por cajeros.
- Colores contrastantes para alertas (stock bajo, errores) y confirmaciones (venta registrada).

## Tokens y paleta (conceptual)

- Color principal: Pendiente de definición por branding.
- Colores de estado: `success` (verde), `warning` (amarillo), `danger` (rojo).
- Tipografía: sans-serif legible; tamaños: `base` 16px, `button` 18px.

## Componentes clave

- `Header` con información de tienda y usuario logueado.
- `POS` (pantalla principal) con buscador rápido de productos, lista de items y total.
- `ProductCard` para seleccionar o editar cantidad.
- `Dialogs` para confirmaciones (anular venta, confirmar recepción de pedido).

## Accesibilidad

- Contraste de colores y tamaño de letra: cumplir WCAG AA cuando sea posible.

## Observaciones

- Assets de marca, iconografía y estilos concretos no están en el SRS: Pendiente de definición por el equipo de UX/branding.
