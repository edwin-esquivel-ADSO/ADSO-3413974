# wireframes

> Estado: 🟡 | Última actualización: 2026-04-11
> Autor: Equipo 3

## Wireframes sugeridos

- `POS` — caja principal con buscador (`input`), lista de items (producto, cantidad, precio, subtotal), total y botones de pago.
- `Login` — campos `usuario`, `contraseña` y opciones de recuperación (si aplica).
- `Inventario` — tabla con filtros por categoría, búsqueda por código, acciones para ajuste de stock.
- `Crear Pedido` — formulario para agregar ítems y enviar solicitud al proveedor.

## Formatos de entrega

- Fuentes: bocetos en `assets/diagrams/` o herramientas de diseño (Figma/Sketch). Exportar PNG/SVG en `assets/images`.

## Observaciones

- Wireframes detallados y prototipos interactivos quedan fuera del SRS y deben validarse con usuarios finales: Pendiente de definición.
