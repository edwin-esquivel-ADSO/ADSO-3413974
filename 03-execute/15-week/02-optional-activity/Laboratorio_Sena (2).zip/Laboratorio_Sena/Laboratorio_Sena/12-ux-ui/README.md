# UX/UI

> Estado: 🟡 | Última actualización: 2026-04-11
> Autor: Equipo 3

Documenta sistema de diseño, navegación y wireframes alineados con los requerimientos del SRS v1.0, priorizando rapidez de uso y claridad para cajeros.

## Archivos

| Archivo | Descripción | Estado |
|---------|-------------|--------|
| [design-system.md](./design-system.md) | Tokens, componentes, patrones visuales y reglas UX/UI | 🟡 |
| [navigation-map.md](./navigation-map.md) | Mapa de navegación y jerarquía de pantallas | 🟡 |
| [wireframes.md](./wireframes.md) | Wireframes y referencias de interacción | 🟡 |

Notas: las decisiones visuales finales y assets de marca (logos, paleta exacta) deben validarse con el cliente; si no hay especificación en el SRS, marcar: Pendiente de definición por el equipo de UX.
