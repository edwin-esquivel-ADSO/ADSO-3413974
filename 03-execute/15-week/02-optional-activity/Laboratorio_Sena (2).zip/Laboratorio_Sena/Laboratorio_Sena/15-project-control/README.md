# Control de Proyecto

> Estado: � | Última actualización: 2026-07-03
> Autor: Equipo de Gestión del Proyecto

Centraliza backlog técnico, riesgos, dependencias y preguntas abiertas. Esta sección ayuda en la toma de decisiones y en la priorización de entregables alineados con el SRS v1.0.

## Archivos

| Archivo | Descripción | Estado |
|---------|-------------|--------|
| [technical-backlog.md](./technical-backlog.md) | Pendientes técnicos y deuda documentada | 🟡 |
| [risks.md](./risks.md) | Riesgos, impacto, probabilidad y mitigación | 🟡 |
| [dependencies.md](./dependencies.md) | Dependencias internas y externas | 🟡 |
| [open-questions.md](./open-questions.md) | Preguntas pendientes de decisión o aclaración | 🟡 |
| [maintenance.md](./maintenance.md) | Procedimientos de mantenimiento y soporte | � |

Notas: mantener este documento vivo; cualquier decisión arquitectónica relevante debe generar un ADR en `05-architecture/decisions/records/`.
