# Maintenance

> Estado: � | Última actualización: 2026-07-03
> Autor: Equipo de Operaciones

## Contexto

Procedimientos mínimos para mantenimiento preventivo, actualizaciones y soporte del `Sistema de Gestión Comercial – Supermercado La Esquina` versión 1.0 (aplicación de escritorio local). Si el SRS no define un aspecto, se marcará: "Pendiente de definición por el equipo de arquitectura".

## Tareas periódicas

- Backup de base de datos: diario al final del día de cierre (`CierreDelDia`).
- Verificación de integridad de archivos de datos: semanal.
- Actualización de la aplicación: según política de releases (ver `10-devops/ci-cd.md`).

## Pasos para actualización menor (parche)

1. Preparar release en rama `release/<iteracion>`.
2. Ejecutar script de migración en entorno staging (si aplica).
3. Ejecutar pruebas de humo (smoke tests).
4. Programar ventana de mantenimiento local fuera de horario pico.
5. Aplicar actualización y verificar logs.

## Copias de seguridad y restauración

- Los backups se almacenan en la ruta configurada por `Operaciones`.
- Restauración: seguir `13-operations/backup-and-recovery.md`.

## Monitoreo y alertas

Pendiente de definición por el equipo de arquitectura: métricas, umbrales y herramientas de monitoreo.

## Soporte y escalamiento

- Soporte de primer nivel: equipo de operaciones local.
- Escalamiento a arquitectura para problemas de integridad o seguridad.

## Checklist de mantenimiento rápido

- [ ] Backup completo reciente
- [ ] Logs revisados por errores críticos
- [ ] Versión de la aplicación documentada

## Referencias

- `13-operations/backup-and-recovery.md`
- `10-devops/ci-cd.md`
