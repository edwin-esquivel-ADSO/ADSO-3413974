# risks

> Estado: 🟡 | Última actualización: 2026-04-11
> Autor: Equipo de Gestión del Proyecto

| Riesgo | Impacto | Probabilidad | Mitigación | Responsable |
|--------|---------|-------------|-----------|------------|
| Pérdida de datos en punto de venta | Alto | Media | Backups diarios (`CopiaSeguridadCreada`), pruebas de restauración | Operaciones |
| Error en cálculo de precios o subtotales | Alto | Baja-Media | Pruebas unitarias y revisión de reglas de negocio en `02-domain` | Desarrollo |
| No aceptación de interfaz por usuarios (cajeros) | Medio | Media | Validación con usuarios, wireframes y pruebas de usabilidad | Producto/UX |
| Falta de claridad en requisitos no cubiertos por SRS | Medio | Alta | Registrar preguntas abiertas y generar ADRs cuando aplique | Gestión/Arquitectura |

## Observaciones

- Añadir nuevos riesgos conforme se descubran durante implementación y pruebas piloto.
