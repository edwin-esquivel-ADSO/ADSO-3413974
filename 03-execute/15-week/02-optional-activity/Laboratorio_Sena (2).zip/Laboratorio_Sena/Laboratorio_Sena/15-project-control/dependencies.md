# dependencies

> Estado: 🟡 | Última actualización: 2026-04-11
> Autor: Equipo de Gestión del Proyecto

## Dependencias internas

- `06-data` (modelo de datos) — referencia obligatoria para cualquier migración.
- `05-architecture` — decisiones arquitectónicas que afectan el backlog técnico.

## Dependencias externas (potenciales)

- Motor de base de datos local (SQLite, PostgreSQL embebido) — elección pendiente.
- Librerías de UI/instalador (Electron, .NET, paquete nativo) — pendiente.
- Broker de eventos (RabbitMQ/Kafka) — solo si se decide arquitectura distribuida.

## Notas

- Muchas dependencias tecnológicas no están definidas en el SRS: Pendiente de definición por el equipo de arquitectura y DevOps. Registrar decisiones en ADRs.
