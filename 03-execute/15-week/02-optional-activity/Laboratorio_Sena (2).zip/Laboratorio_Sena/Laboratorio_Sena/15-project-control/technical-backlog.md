# technical-backlog

> Estado: 🟡 | Última actualización: 2026-04-11
> Autor: Equipo de Gestión del Proyecto

Entradas técnicas derivadas del SRS y trabajo de documentación.

| ID | Tarea técnica | Prioridad | Área | Estado |
|----|--------------|----------:|------|-------|
| TB-001 | Definir motor de persistencia y esquema físico (tipos, longitudes) | Alta | Data | ABIERTA |
| TB-002 | Implementar migraciones y scripts de respaldo | Alta | DevOps / Data | ABIERTA |
| TB-003 | Diseñar instalador y proceso de actualización | Alta | DevOps | ABIERTA |
| TB-004 | Crear ADRs para decisiones de seguridad y tokens | Media | Architecture | ABIERTA |
| TB-005 | Prototipo de UI de `POS` y validación con usuarios | Media | UX | ABIERTA |

## Observaciones

- Añadir tareas según resultados de pruebas y retroalimentación de clientes.
