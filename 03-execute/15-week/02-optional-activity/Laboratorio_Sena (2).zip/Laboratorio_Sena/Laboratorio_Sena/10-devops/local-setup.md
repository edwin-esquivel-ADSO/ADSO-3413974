# Local setup

> Estado: 🟡 | Última actualización: 2026-04-11
> Autor: Equipo 3

## Objetivo

Describir pasos para preparar un entorno de desarrollo y el equipo del punto de venta para la instalación de la aplicación de escritorio.

## Desarrollo (desarrollador)

1. Activar entorno virtual Python (ejemplo `.venv`):

```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy RemoteSigned
.\.venv\Scripts\Activate.ps1
```

2. Instalar dependencias (si aplica):

```powershell
pip install -r requirements.txt
```

3. Ejecutar scripts de extracción o pruebas unitarias según convención del repositorio.

## Instalación en punto de venta (operador)

- Uso de instalador nativo (MSI/EXE) o paquete portable: el instalador debe crear una copia de seguridad antes de actualizar.
- Documentar pasos de rollback y contacto de soporte.

## Observaciones

- Detalles del instalador y requisitos de SO/hardware: Pendiente de definición por el equipo de arquitectura.
