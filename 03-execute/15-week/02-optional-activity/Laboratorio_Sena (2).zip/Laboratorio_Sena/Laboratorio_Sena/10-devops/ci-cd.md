# CI/CD

> Estado: 🟡 | Última actualización: 2026-04-11
> Autor: Equipo 3

## Propósito

Describir pipelines y controles automatizados. Dado el alcance local de la versión 1.0, los pipelines se centran en calidad de código, artefactos de instalación y pruebas automatizadas.

## Pipelines sugeridos

- `build` — Instala dependencias y construye artefacto instalable.
- `test` — Ejecuta pruebas unitarias y flake/linters.
- `package` — Genera instalador (MSI/EXE) o paquete portable.
- `release` — Publica artefacto en repositorio interno o genera paquete para distribución.

## Políticas

- Repositorios deben incluir `requirements.txt` y scripts para reproducir la construcción local.
- Firmado de instaladores y control de versiones en etiquetas Git: Pendiente de definición.

## Observaciones

- Herramientas concretas (GitHub Actions, Azure Pipelines, Jenkins) no están definidas en el SRS: Pendiente de definición por el equipo de DevOps/arquitectura.
