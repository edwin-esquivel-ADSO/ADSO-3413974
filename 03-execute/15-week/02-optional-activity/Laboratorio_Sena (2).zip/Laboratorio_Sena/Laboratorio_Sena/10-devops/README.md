# DevOps

> Estado: 🟡 | Última actualización: 2026-04-11
> Autor: Equipo 3

Documenta la instalación local, pipelines y ambientes. Dado que la versión 1.0 es una aplicación de escritorio desplegada localmente en puntos de venta, las prácticas de DevOps se enfocan en instaladores, actualizaciones controladas y procesos de backup/migración.

## Archivos

| Archivo | Descripción | Estado |
|---------|-------------|--------|
| [local-setup.md](./local-setup.md) | Preparación del entorno local de desarrollo | 🟡 |
| [ci-cd.md](./ci-cd.md) | Pipelines, despliegues y controles de calidad automatizados | 🟡 |
| [environments.md](./environments.md) | Ambientes, propósito y reglas de uso | 🟡 |

Notas: decisiones sobre herramientas CI/CD, repositorio de artefactos e instaladores deben registrarse en ADRs.
