# Environments

> Estado: 🟡 | Última actualización: 2026-04-11
> Autor: Equipo 3

## Propósito

Describir los ambientes operativos y su propósito. Para la v1.0, el despliegue principal es local en el punto de venta.

## Ambientes sugeridos

- `development` — entorno de desarrollo local para programadores.
- `staging` — entorno de preproducción para validar instaladores y migraciones (opcional).
- `production` — equipos en puntos de venta con instalador oficial.

## Reglas de uso

- Antes de aplicar actualizaciones en `production`: generar backup y validar en `staging` (si existe).
- Control de versiones mediante etiquetas Git y versión del instalador.

## Observaciones

- El SRS no define ambientes en nube ni despliegues remotos; políticas de staging y producción deben establecerse según capacidad del cliente.
