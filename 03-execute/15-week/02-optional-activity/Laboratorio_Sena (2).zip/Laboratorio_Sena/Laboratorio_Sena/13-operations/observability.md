# observability

> Estado: 🟡 | Última actualización: 2026-04-11
> Autor: Equipo 3

## Objetivo

Definir métricas, logs y alertas mínimas para detectar problemas en la operación del punto de venta.

## Métricas mínimas

- Transacciones por hora/día (ventas registradas).
- Número de fallos de registro de venta.
- Latencia de operaciones críticas (registro de venta, actualización de inventario).

## Logs

- Registrar eventos críticos: login fallido, `VentaRegistrada`, `RecepcionConfirmada`, errores de persistencia.
- Logs locales rotativos con retención configurable (ver `cross-cutting.md`).

## Alertas

- Alertas locales para `StockMinimoAlcanzado` y fallos de copia de seguridad.

## Observaciones

- Dado el despliegue local, la telemetría remota es opcional; si se habilita, requerirá consentimiento y acuerdos de privacidad no especificados en el SRS.
