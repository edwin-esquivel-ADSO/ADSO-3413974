# backup-and-recovery

> Estado: 🟡 | Última actualización: 2026-04-11
> Autor: Equipo 3

## Objetivo

Definir políticas mínimas de copia de seguridad y recuperación para proteger los datos del punto de venta.

## Política mínima recomendada

- Copia de seguridad automática diaria generada durante `CierreDelDia` (evento `CopiaSeguridadCreada`).
- Mantener al menos 7 días de backups locales por defecto (política ajustable).
- Antes de aplicar migraciones o actualizaciones: generar backup completo y verificar integridad.

## Procedimiento de restauración (resumen)

1. Detener la aplicación en el equipo afectado.
2. Restaurar archivos de backup desde la ubicación local o dispositivo de respaldo.
3. Ejecutar validaciones básicas (número de ventas, integridad de FK).
4. Iniciar la aplicación y verificar operaciones críticas.

## Observaciones

- Políticas de ubicación de backups (disco local vs red) y retención exacta no están especificadas en el SRS: Pendiente de definición por operaciones.
