# incident-management

> Estado: 🟡 | Última actualización: 2026-04-11
> Autor: Equipo 3

## Objetivo

Clasificar, responder y comunicar incidentes que afecten la operación del punto de venta.

## Clasificación (ejemplo)

- Sev 1 (Crítica): pérdida total de ventas o corrupción de datos que impide operar.
- Sev 2 (Alta): funcionalidades críticas degradadas (cobro, actualización de inventario).
- Sev 3 (Media): errores que afectan operaciones no críticas o intermitencias.

## Respuesta y escalamiento

1. Detección: operador reporta o sistema genera alerta.
2. Contención: pasos inmediatos para minimizar impacto (cerrar aplicación, usar caja manual si aplica).
3. Diagnóstico: revisar logs y backups, reproducir problema en entorno controlado.
4. Recuperación: restaurar desde backup si es necesario y validar operaciones.
5. Post-mortem: registrar causa raíz y acciones preventivas.

## Comunicación

- Notificar al dueño del comercio y al equipo de soporte según el SLA (detalles de contacto: Pendiente).

## Observaciones

- Procedimientos detallados y contactos deben definirse fuera del SRS y añadirse aquí.
