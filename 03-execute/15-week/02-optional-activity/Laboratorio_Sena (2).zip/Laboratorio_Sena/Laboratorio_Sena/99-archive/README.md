# Archive

> Estado: 🟢 Completo | Última actualización: 2026-04-11
> Autor: Equipo 3

Repositorio de artefactos y decisiones históricas ya no activas. Mantener como referencia; no mover ni eliminar sin registrar un ADR.

## Uso

- Colocar aquí documentos deprecados, decisiones antiguas y artefactos obsoletos. Para decisiones de arquitectura activas use `05-architecture/decisions/records/`.

## Carpetas

| Carpeta | Descripción |
|---------|-------------|
| [deprecated/](./deprecated/) | Documentos que ya no aplican |
| [old-decisions/](./old-decisions/) | Decisiones antiguas preservadas por historia |
