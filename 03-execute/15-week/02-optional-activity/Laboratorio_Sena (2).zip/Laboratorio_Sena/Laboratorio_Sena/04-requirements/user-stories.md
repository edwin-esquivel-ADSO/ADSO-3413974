# user-stories

> Estado: 🟡 | Última actualización: 2026-04-11
> Autor: Equipo 3

## Historias de usuario (alto nivel) y criterios de aceptación

1. Como `Cajero`, quiero `registrar una venta` para `procesar el pago y entregar el comprobante al cliente`.
	 - Criterios de aceptación:
		 - Se pueden agregar múltiples productos con cantidades.
		 - El sistema calcula subtotales, total y cambio automáticamente.
		 - La venta queda registrada y decrementa el inventario.
		 - Se genera un ticket disponible para imprimir o exportar.

2. Como `Administrador`, quiero `generar el cierre de día` para `obtener un resumen de ventas y copia de seguridad`.
	 - Criterios de aceptación:
		 - El cierre muestra total de ventas, número de transacciones, ticket promedio, top 5 productos y productos agotados.
		 - Se ofrece exportar/imprimir el reporte y se genera una copia de seguridad.

3. Como `Empleado de bodega`, quiero `registrar la recepción de un pedido` para `actualizar el inventario automáticamente`.
	 - Criterios de aceptación:
		 - Se puede seleccionar un pedido pendiente y marcarlo como recibido.
		 - El stock de cada producto se incrementa según lo recibido.

4. Como `Administrador`, quiero `gestionar proveedores` para `mantener un directorio actualizado y crear pedidos`.
	 - Criterios de aceptación:
		 - Crear/editar proveedores con NIT, contacto y condiciones.
		 - Detectar intención de duplicado por NIT o nombre y solicitar confirmación.

5. Como `Administrador`/`Cajero`, quiero `iniciar sesión` para `acceder al sistema con permisos adecuados`.
	 - Criterios de aceptación:
		 - Usuarios con rol `Cajero` no pueden ejecutar cierres de día ni cambiar configuración.
		 - Usuarios con rol `Administrador` pueden ejecutar cierres de día y acceder a reportes y configuración.

## Notas

- Aceptación detallada (mensajes exactos, formatos de exportación, campos obligatorios) no está completamente especificada en el SRS: Pendiente de definición por el equipo de arquitectura.
