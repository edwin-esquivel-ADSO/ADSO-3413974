# non-functional

> Estado: 🟡 | Última actualización: 2026-04-11
> Autor: Equipo 3

Los requisitos de calidad que siguen se derivan del SRS v1.0 y de las necesidades operativas del negocio. Donde el SRS no especifica valores o límites concretos, se indica "Pendiente de definición por el equipo de arquitectura".

## Requisitos no funcionales (resumen)

- RNF-01: Plataforma y despliegue
	- La versión 1.0 es una aplicación de escritorio para uso local en el punto de venta. (SRS: alcance para aplicación de escritorio). Detalles de SO soportados: Pendiente de definición por el equipo de arquitectura.

- RNF-02: Rendimiento
	- Operaciones de venta deben completarse en tiempo perceptible para el usuario (objetivo: < 2 segundos por operación de cálculo y confirmación). Valores exactos medibles: Pendiente de definición.

- RNF-03: Persistencia y respaldo
	- Datos persistidos localmente; copia de seguridad automática durante cierre de día. Política de retención y ubicación de backup: Pendiente de definición.

- RNF-04: Seguridad
	- Contraseñas almacenadas de forma segura (hash). Control de acceso por roles. Requisitos de cifrado en reposo y en tránsito: Pendiente de definición.

- RNF-05: Disponibilidad
	- Debe operar durante las horas comerciales normales (7 días a la semana). Objetivos de disponibilidad y recuperación ante fallos: Pendiente de definición.

- RNF-06: Usabilidad
	- Interfaz simple y optimizada para operación en punto de venta con usuarios no técnicos (cajero). Requiere capacitación mínima según SRS.

- RNF-07: Mantenibilidad
	- Código y documentación suficientes para permitir cambios y correcciones por el equipo de desarrollo; matriz de trazabilidad entre requisitos y pruebas.

## Observaciones

- Muchas especificaciones cuantitativas (SLA, RTO, RPO, requisitos de carga, compatibilidad exacta de SO y hardware) no están en el SRS: Pendiente de definición por el equipo de arquitectura.
