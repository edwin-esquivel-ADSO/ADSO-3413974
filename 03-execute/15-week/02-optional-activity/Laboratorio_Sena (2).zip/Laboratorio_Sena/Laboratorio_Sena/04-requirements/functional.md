# functional

> Estado: 🟡 | Última actualización: 2026-04-11
> Autor: Equipo 3

Los requisitos funcionales que siguen se derivan directamente del SRS v1.0 (Sistema de Gestión Comercial — Supermercado La Esquina). Los identificadores `RF-xx` se mantienen tal como aparecen en el SRS cuando están presentes; donde el SRS no proporciona un identificador explícito, se listan en orden lógico.

## Requisitos funcionales (resumen)

- RF-01: Registrar venta
	- El cajero selecciona productos; el sistema calcula subtotales, total y cambio automáticamente. Ver CU-001.

- RF-02: Consultar historial de ventas
	- Permitir la consulta por fecha y rango, y mostrar detalle de transacciones.

- RF-03: Control de inventario
	- Mantener `stockActual` por producto; actualizarlo inmediatamente al registrar ventas o recepcionar pedidos.

- RF-04: Alertas de stock mínimo
	- Generar alerta cuando `stockActual <= stockMinimo` y registrar evento `StockMinimoAlcanzado`.

- RF-05: Registro y gestión de proveedores
	- Crear/editar proveedores con datos: nombre, NIT, teléfono, correo, productos y condiciones de pago. Detectar duplicados por NIT o nombre.

- RF-06: Gestión de pedidos a proveedores
	- Crear pedido, mantener estado (Pendiente, Recibido), y al confirmar recepción actualizar inventario.

- RF-07: Cierre de día y reportes
	- Generar cierre de día con: total de ventas, número de transacciones, ticket promedio, top 5 productos, productos agotados y saldo de caja esperado. Permitir impresión/exportación y generar copia de seguridad automática.

- RF-08: Copia de seguridad automática
	- Generar copia de seguridad durante el cierre de día y registrar `CopiaSeguridadCreada`.

- RF-09: Autenticación
	- Inicio de sesión con credenciales locales; registrar autenticaciones exitosas y fallidas.

- RF-10: Control de acceso por roles
	- Roles mínimos: `Administrador` y `Cajero`. El Administrador puede ejecutar cierre de día y gestionar configuración; el Cajero registra ventas.

- RF-11: Exportación e impresión
	- Permitir exportar reportes a PDF y opción de impresión local.

- RF-12: Auditoría e historial
	- Mantener historial de ventas, pedidos y recepciones para auditoría y consulta.

## Observaciones

- Donde el SRS no especifica formatos, longitudes, validaciones o detalles de integración, se ha dejado indicado: "Pendiente de definición por el equipo de arquitectura." 
- Para casos de borde (transacciones parciales, fallos en actualización de inventario) las políticas de transacción y rollback deben definirse en diseño técnico.
