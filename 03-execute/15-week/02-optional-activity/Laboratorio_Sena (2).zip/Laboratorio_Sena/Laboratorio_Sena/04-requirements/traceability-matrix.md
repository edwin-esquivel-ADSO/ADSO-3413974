# traceability-matrix

> Estado: 🟡 | Última actualización: 2026-04-11
> Autor: Equipo 3

Esta matriz relaciona a alto nivel requisitos funcionales, casos de uso y las historias de usuario documentadas en el SRS.

| Requisito (RF) | Caso de uso (CU) | Historia de usuario |
|---------------:|------------------|---------------------|
| RF-01 Registrar venta | CU-001 Registrar una venta | Historia 1: Registrar una venta (Cajero) |
| RF-02 Consultar ventas | CU-002 Consultar ventas | Historia 1 / Historia 2 |
| RF-03 Control de inventario | CU-003 Gestionar inventario | Historia 3: Recepción de pedido (Empleado bodega) |
| RF-05 Registro proveedores | CU-004 Registrar proveedor y pedido | Historia 4: Gestionar proveedores (Administrador) |
| RF-07 Cierre de día / reportes | CU-00X Cierre del día | Historia 2: Generar cierre de día (Administrador) |
| RF-09 Autenticación | CU-00Y Autenticación | Historia 5: Iniciar sesión (Administrador / Cajero) |

> Nota: Los identificadores CU y su correspondencia exacta aparecen en el SRS (por ejemplo CU-001). Para una matriz completa a nivel de requisito/escenario y prueba, expandir con el equipo de QA.
