# Requisitos

> Estado: 🟡 | Última actualización: 2026-04-11
> Autor: Equipo 3

## Contenido

Contiene los requisitos funcionales y no funcionales identicados en el SRS v1.0, las historias de usuario de alto nivel y una matriz de trazabilidad inicial.

## Archivos

| Archivo | Descripción | Estado |
|---------|-------------|--------|
| [functional.md](./functional.md) | Requisitos funcionales del sistema | 🟡 |
| [non-functional.md](./non-functional.md) | Requisitos de calidad, seguridad, rendimiento y operación | 🟡 |
| [user-stories.md](./user-stories.md) | Historias de usuario y criterios de aceptación | 🟡 |
| [traceability-matrix.md](./traceability-matrix.md) | Relación entre requisitos, historias, decisiones y pruebas | 🟡 |

La matriz y los requisitos han sido alineados con el SRS. Los criterios cuantitativos y formatos no descritos en el SRS se han marcado como "Pendiente de definición por el equipo de arquitectura" y requieren definición en la fase de diseño técnico.
