# roadmap

> Estado: 🟡 | Última actualización: 2026-04-11
> Autor: Equipo 3

## Hitos y versiones (resumen)

- **v1.0 (MVP)** — Entregable principal (alineado con SRS v1.0):
	- Registro y consulta de ventas (punto de venta).
	- Control de inventario con actualización automática y alertas de stock mínimo.
	- Registro y gestión de proveedores y pedidos (historial y recepción).
	- Reportes básicos: cierre de día, ventas diarias/mensuales, top productos, productos agotados.
	- Autenticación y control de acceso por roles (Administrador, Cajero).

- **v1.1 (mejoras operativas)**
	- Mejoras en exportación/imprenta de reportes (PDF), ajuste de formatos y pequeñas optimizaciones de UX.

- **v2.0 (funcionalidades planificadas en SRS como fuera de alcance para v1.0)**
	- Integración con facturación electrónica (DIAN).
	- Integraciones con pasarelas de pago / datáfonos.
	- Evaluación futura de versión web o móvil (solo si el negocio lo requiere).

## Calendario tentativo

- MVP (v1.0): definición de requisitos detallados → diseño → implementación básica → pruebas en entorno local → entrega y capacitación al comerciante.
- Fechas específicas y alcance de iteraciones quedan pendientes de planificación con el equipo del proyecto.

## Observaciones

El roadmap prioriza la entrega de valor operativo localmente en el punto de venta, tal como indica el SRS. Todos los elementos fuera del alcance en la SRS v1.0 se mantienen como hitos futuros y requieren aprobación del cliente y del equipo de arquitectura.
