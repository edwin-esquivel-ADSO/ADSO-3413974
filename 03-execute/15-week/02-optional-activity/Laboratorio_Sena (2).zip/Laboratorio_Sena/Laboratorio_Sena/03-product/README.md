# Producto

> Estado: 🟡 | Última actualización: 2026-04-11
> Autor: Equipo 3

## Contenido

Contiene la visión del producto, el roadmap de alto nivel y el backlog priorizado alineados con el SRS v1.0.

## Archivos

| Archivo | Descripción | Estado |
|---------|-------------|--------|
| [vision.md](./vision.md) | Visión, objetivos de producto y propuesta de valor | 🟡 |
| [roadmap.md](./roadmap.md) | Hitos, fases y evolución planificada | 🟡 |
| [product-backlog.md](./product-backlog.md) | Backlog priorizado de producto | 🟡 |

La priorización está basada en el valor para el negocio y en el alcance definido por el SRS. Para elementos sin especificación suficiente se ha colocado la marca: "Pendiente de definición por el equipo de arquitectura." 
