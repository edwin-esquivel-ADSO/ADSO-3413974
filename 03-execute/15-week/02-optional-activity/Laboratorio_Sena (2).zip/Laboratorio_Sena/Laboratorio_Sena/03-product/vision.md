# vision

> Estado: 🟡 | Última actualización: 2026-04-11
> Autor: Equipo 3

## Visión del producto

El "Sistema de Gestión Comercial — Supermercado La Esquina" proveerá a pequeños comercios una solución de escritorio fiable y simple que automatiza ventas, controla el inventario y gestiona proveedores, permitiendo a los propietarios operar con mayor eficiencia, reducir pérdidas por errores de cobro y tomar decisiones basadas en reportes oportunos.

## Propuesta de valor

- Reducir el tiempo de atención por cliente mediante cálculo automático de precios y cambio.
- Disminuir pérdidas económicas por errores de cobro y controles manuales.
- Evitar desabastecimientos mediante alertas de stock mínimo y gestión de pedidos.
- Entregar reportes operativos (cierre de día, ventas diarias/mensuales, top productos) para la toma de decisiones.

## Usuarios objetivo

- Propietario/Administrador (Don Carlos R.).
- Cajero(a) responsable de ventas.
- Empleado de bodega encargado de recepción y control de stock.

## Métricas de éxito (MVP)

- Tiempo promedio de atención por cliente reducido a < 2 minutos (medible tras adopción).
- Reducción de errores de cobro en al menos 80% respecto al proceso manual.
- Disminución de eventos de desabastecimiento recurrente en el catálogo gestionado.

## Observaciones

Todas las afirmaciones y prioridades están basadas en la SRS v1.0. Funcionalidades fuera del alcance del MVP (facturación electrónica, integraciones de pago, versión web/móvil) quedan planificadas para versiones futuras según el SRS.
