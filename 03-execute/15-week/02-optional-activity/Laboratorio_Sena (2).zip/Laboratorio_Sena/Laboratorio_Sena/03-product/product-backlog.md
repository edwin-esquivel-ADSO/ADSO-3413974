# product-backlog

> Estado: 🟡 | Última actualización: 2026-04-11
> Autor: Equipo 3

Este backlog de alto nivel refleja los requerimientos funcionales priorizados del SRS v1.0. No contiene estimaciones de tiempo; priorización basada en valor para el negocio y riesgo técnico.

## Backlog priorizado (alto nivel)

1. Ventas en Punto de Venta (Alta)
	- Registrar venta con items, calcular totales y cambio, generar ticket.
	- Validar existencia de stock antes de confirmar venta.

2. Control de Inventario (Alta)
	- Actualización automática de stock al registrar ventas y recepciones.
	- Alertas de stock mínimo por producto.

3. Gestión de Proveedores y Pedidos (Alta)
	- Crear/editar proveedores, crear pedidos, confirmar recepción y actualizar stock.
	- Detección básica de proveedores duplicados (por NIT o nombre) con confirmación.

4. Autenticación y Control de Acceso (Alta)
	- Roles: Administrador y Cajero; permisos diferenciados (cierres, configuración solo Administrador).

5. Reportes y Cierre de Día (Alta)
	- Cierre del día con resumen: total de ventas, número de transacciones, ticket promedio, top 5 productos, productos agotados, saldo de caja esperado.
	- Exportar a PDF o imprimir (según flujo SRS).

6. Copia de Seguridad Automática (Media)
	- Generar copia de seguridad durante el cierre de día.

7. Exportación e impresión (Media)
	- Exportar reportes a PDF y ofrecer opción de impresión.

8. Ajustes y correcciones de inventario (Media)
	- Registro de ajustes por pérdida, daño o conteo físico.

9. Auditoría e historial (Baja)
	- Historial de ventas, pedidos y recepciones para auditoría.

## Notas

- Elementos fuera del alcance del MVP (facturación electrónica, integraciones de pago, app móvil/web) están documentados en SRS y planificados para versiones futuras.
- Para tareas con campos/formatos no especificados en el SRS, colocar: "Pendiente de definición por el equipo de arquitectura." 
