# events (plantilla)

> Estado: 🟡 | Última actualización: YYYY-MM-DD
> Autor: Nombre Apellido | Equipo: nombre-del-equipo

## Eventos de dominio recomendados (extraídos del SRS)

- `VentaRegistrada` — emitido al confirmar una venta. Payload: `ventaId`, `fechaHora`, `total`, `items`.
- `InventarioActualizado` — cuando cambia `stockActual` de un producto. Payload: `productoId`, `stockAnterior`, `stockNuevo`.
- `ProveedorRegistrado` — al crear un proveedor.
- `PedidoCreado` — al generar un pedido a proveedor.
- `RecepcionConfirmada` — al recibir mercancía y actualizar `cantidadRecibida`.
- `StockMinimoAlcanzado` — alerta cuando `stockActual` < `stockMinimo`.
- `CierreDelDiaGenerado` — resumen diario de ventas y cierre.
- `CopiaSeguridadCreada` — cuando se genera backup durante cierre de día.

## Observaciones

- Especificar esquemas JSON para cada evento en la documentación del servicio.
