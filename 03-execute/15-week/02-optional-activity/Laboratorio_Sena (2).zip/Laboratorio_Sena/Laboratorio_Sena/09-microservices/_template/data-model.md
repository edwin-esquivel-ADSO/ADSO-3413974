# Data Model (plantilla)

> Estado: 🟡 | Última actualización: YYYY-MM-DD
> Autor: Nombre Apellido | Equipo: nombre-del-equipo

## Propósito

Describir el modelo de datos específico del servicio (tablas, claves, índices, restricciones). Para conceptos globales, referenciar `06-data/models.md` y `06-data/data-dictionary.md`.

## Ejemplo (resumen)

- Tablas: `productos`, `ventas`, `venta_items`, `proveedores`, `pedidos`, `pedido_items`, `usuarios`.
- Índices: `productoId`, `ventaId`, `fechaHora`.

## Observaciones

- Tipos concretos y longitudes quedan pendientes y deben decidirse en la etapa de diseño físico.
