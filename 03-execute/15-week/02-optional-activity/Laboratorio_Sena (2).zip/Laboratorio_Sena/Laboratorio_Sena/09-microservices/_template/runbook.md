# runbook (plantilla)

> Estado: 🟡 | Última actualización: YYYY-MM-DD
> Autor: Nombre Apellido | Equipo: nombre-del-equipo

## Propósito

Pasos operativos para desplegar, actualizar y recuperar el servicio en caso de incidentes.

## Operaciones comunes

- Arranque: pasos para iniciar el servicio y verificar conectividad.
- Actualización: pasos para aplicar migraciones y validar integridad.
- Backup y restauración: pasos para restaurar desde `CopiaSeguridadCreada`.
- Contacto de soporte y escalamiento.

## Verificaciones post-deploy

- Pruebas de humo: endpoints básicos respondiendo, integridad de base de datos.
- Verificación de colas y consumidores (si aplica).

## Observaciones

- Como la versión 1.0 es local, adaptar el runbook a procedimientos manuales para el encargado del punto de venta.
