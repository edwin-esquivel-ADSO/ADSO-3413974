# API Contract (plantilla)

> Estado: 🟡 | Última actualización: YYYY-MM-DD
> Autor: Nombre Apellido | Equipo: nombre-del-equipo

## Propósito

Describir el contrato público del servicio: endpoints, modelos de entrada/salida, códigos de error y requisitos de seguridad.

## Ejemplo de endpoints

- `GET /v1/{resource}` — Listar recursos
- `GET /v1/{resource}/{id}` — Obtener recurso
- `POST /v1/{resource}` — Crear recurso
- `PUT /v1/{resource}/{id}` — Reemplazar recurso
- `PATCH /v1/{resource}/{id}` — Actualizar parcialmente
- `DELETE /v1/{resource}/{id}` — Eliminar recurso (si aplica)

## Seguridad

- Indicar scopes/roles necesarios para cada endpoint.

## Contratos OpenAPI

- Cuando el contrato sea estable, añadir el YAML OpenAPI en `07-api/contracts/openapi/`.
