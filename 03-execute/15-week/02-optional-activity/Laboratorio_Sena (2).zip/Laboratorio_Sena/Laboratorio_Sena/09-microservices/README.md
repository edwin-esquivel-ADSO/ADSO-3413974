# Microservicios

> Estado: 🟡 | Última actualización: 2026-04-11
> Autor: Equipo 3

Esta sección centraliza el catálogo de servicios, los patrones de comunicación y la plantilla para documentar servicios. Según el SRS v1.0 la solución es una aplicación de escritorio; no obstante mantenemos este módulo para futuras subdivisiones en servicios.

## Archivos

| Archivo | Descripción | Estado |
|---------|-------------|--------|
| [service-catalog.md](./service-catalog.md) | Inventario de servicios, owners, repos y estado documental | 🟡 |
| [communication-patterns.md](./communication-patterns.md) | Patrones síncronos, asíncronos y resiliencia | 🟡 |
| [_template/](./_template/) | Plantilla para documentar un servicio nuevo; no representa un microservicio real | 🟡 |
| [services/](./services/) | Documentación específica por microservicio | 🔴 |

Notas: si en el futuro se decide descomponer la aplicación en servicios, use estas plantillas y registre cada servicio en `service-catalog.md` con owner y repositorio.
