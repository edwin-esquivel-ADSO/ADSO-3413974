
# Catálogo de servicios

Listado sugerido de servicios que cubrirían los bounded contexts identificados en el SRS si se optara por un diseño distribuido.

| Servicio | Descripción | Owner | Repo | Estado |
|----------|-------------|-------|------|--------|
| ventas | Registro de ventas y generación de cierres de día | Por definir | Por definir | Pendiente |
| inventario | Gestión de stock, alertas de stock mínimo | Por definir | Por definir | Pendiente |
| proveedores | Gestión de proveedores y pedidos | Por definir | Por definir | Pendiente |
| reportes | Generación de reportes y exportes | Por definir | Por definir | Pendiente |
| seguridad | Autenticación y control de acceso | Por definir | Por definir | Pendiente |
