
# Patrones de comunicación

> Estado: 🟡 | Última actualización: 2026-04-11
> Autor: Equipo 3

## Síncrona

- REST (HTTP/JSON) para operaciones de consulta y comandos simples (p. ej. `GET /productos`, `POST /ventas`).
- gRPC puede considerarse para integraciones internas de baja latencia en futuras versiones: Pendiente de definición.

## Asíncrona (eventos)

- Eventos de dominio recomendados (derivados del SRS): `VentaRegistrada`, `InventarioActualizado`, `ProveedorRegistrado`, `PedidoCreado`, `RecepcionConfirmada`, `StockMinimoAlcanzado`, `CierreDelDiaGenerado`, `CopiaSeguridadCreada`.
- Canal de eventos local (bus ligero) o broker externo (RabbitMQ, Kafka) — elección pendiente.

## Resiliencia

- Retries con backoff exponencial para llamadas externas.
- Circuit breaker para evitar cascadas en fallos.
- Timeouts razonables en llamadas síncronas y operaciones de red.

## Observaciones

- Dado que la versión 1.0 es una aplicación de escritorio local, la arquitectura asíncrona sólo aplica si se externalizan componentes. Todas las decisiones tecnológicas deberán registrarse en ADRs.
