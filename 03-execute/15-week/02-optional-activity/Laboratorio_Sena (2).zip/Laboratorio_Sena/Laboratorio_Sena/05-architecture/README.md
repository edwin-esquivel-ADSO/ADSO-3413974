# Arquitectura

> Estado: 🟡 | Última actualización: 2026-04-11
> Autor: Equipo 3

## Contenido

Contiene la visión arquitectónica alineada con el SRS v1.0: vista general, responsabilidades por contexto, despliegue local y aspectos transversales (seguridad, copia de seguridad, logging). Las decisiones de arquitectura deben registrarse en `decisions/` mediante ADRs.

## Archivos

| Archivo | Descripción | Estado |
|---------|-------------|--------|
| [overview.md](./overview.md) | Vista general de arquitectura y componentes | 🟡 |
| [deployment.md](./deployment.md) | Topología de despliegue y ambientes | 🟡 |
| [cross-cutting.md](./cross-cutting.md) | Seguridad, logging, auditoría, errores y demás aspectos transversales | 🟡 |
| [decisions/](./decisions/) | Registro de decisiones de arquitectura (ADR) | 🟡 |

Notas: La arquitectura propuesta respeta estrictamente el alcance del SRS; cualquier ampliación o elección tecnológica debe registrarse en un ADR y validarse con el cliente.
