# ADR-002: Instalador y proceso de actualización

> Estado: PROPOSED
> Fecha: 2026-07-03
> Autores: Equipo de Arquitectura
> Equipos involucrados: DevOps, Producto, Operaciones

---

## Contexto

El SRS indica entrega de una aplicación de escritorio local. No define el formato del instalador ni la estrategia de actualización automática/manual.

## Decisión

Pendiente de definición por el equipo de arquitectura: formato del instalador (p.ej. instalador nativo de Windows, paquete portatil, uso de Electron auto-updater, o instalador MSI) y política de actualizaciones.

## Consecuencias

### Positivas

- Definir instalador permite planear CI/CD, firmar binarios y establecer rollback.

### Negativas / Trade-offs

- Requiere soporte para firmas y cumplimiento en entornos con políticas de seguridad.

### Riesgos

- Firma/entrega de instaladores puede introducir costos y procesos legales.

## Alternativas consideradas

| Alternativa | Por qué se descartó (por ahora) |
|-------------|---------------------------------|
| Instalador MSI Windows | Robusto para Windows pero necesita proceso de firma |
| Paquete portable | Simple para despliegues locales, menos control central |
| Auto-updater integrado | Conveniente pero añade complejidad al runtime |

## Referencias

- `10-devops/ci-cd.md`
- `15-project-control/technical-backlog.md` (TB-003)

***
