# ADR-004: Herramienta de CI/CD y firmado de artefactos

> Estado: PROPOSED
> Fecha: 2026-07-03
> Autores: Equipo de Arquitectura
> Equipos involucrados: DevOps, Seguridad

---

## Contexto

El SRS no especifica herramientas de integración y entrega. Para asegurar entregas estables y firmas de instaladores, es necesario seleccionar una herramienta de CI/CD y una política de firmado.

## Decisión

Pendiente de definición por el equipo de DevOps/Arquitectura: herramienta de CI/CD (GitHub Actions, Azure Pipelines, Jenkins u otra) y proceso de firmado de instaladores/binaries.

## Consecuencias

### Positivas

- Establecer pipeline facilitará pruebas automáticas y releases controlados.

### Riesgos

- Requiere configuración de secretos, acceso y posiblemente costos.

## Alternativas consideradas

| Alternativa | Por qué se descartó (por ahora) |
|-------------|---------------------------------|
| GitHub Actions | Integrado con GitHub; requiere gestión de secretos para firma |
| Azure Pipelines | Robusto; puede integrarse con registries corporativos |
| Jenkins | Flexible pero mayor mantenimiento |

## Referencias

- `10-devops/ci-cd.md`
- `15-project-control/technical-backlog.md` (TB-003)

***
