# ADR-003: Autenticación y gestión de sesiones

> Estado: PROPOSED
> Fecha: 2026-07-03
> Autores: Equipo de Arquitectura
> Equipos involucrados: Seguridad, Desarrollo, Operaciones

---

## Contexto

El SRS indica control de acceso por roles (Administrador, Cajero) y almacenamiento seguro de credenciales, pero no especifica mecanismos (hashing, tokens, expiraciones) ni si se requiere autenticación centralizada.

## Decisión

Pendiente de definición por el equipo de arquitectura: método de autenticación (local con contraseñas hasheadas vs integración con servicio externo), formato de tokens si aplica, políticas de expiración y rotación.

## Consecuencias

### Positivas

- Documentar la decisión mejorará los procedimientos de soporte y seguridad.

### Riesgos

- Mala elección puede afectar seguridad o usabilidad.

## Alternativas consideradas

| Alternativa | Por qué se descartó (por ahora) |
|-------------|---------------------------------|
| Autenticación local (hash PBKDF2/Bcrypt) | Compatible con operación offline; pendiente parámetros exactos |
| Servicio externo / SSO | Más seguro para entornos corporativos, pero no necesario para un punto de venta local |

## Referencias

- `04-requirements/non-functional.md`
- `00-governance/security-rules.md`

***
