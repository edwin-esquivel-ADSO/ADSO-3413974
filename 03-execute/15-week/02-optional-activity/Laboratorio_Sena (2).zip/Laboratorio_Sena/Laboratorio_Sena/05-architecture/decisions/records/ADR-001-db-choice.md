# ADR-001: Motor de persistencia

> Estado: PROPOSED
> Fecha: 2026-07-03
> Autores: Equipo de Arquitectura
> Equipos involucrados: Data, DevOps, Desarrollo

---

## Contexto

El SRS (v1.0) define una aplicación de escritorio local para el "Supermercado La Esquina" con un catálogo de ~90 productos y operación local (40-60 clientes diarios). No se especifica un motor de persistencia ni detalles físicos (tipos, longitudes, UUID vs int).

## Decisión

Pendiente de definición por el equipo de arquitectura: elegir el motor de persistencia (p.ej. SQLite embebido, PostgreSQL embebido/ligero, o fichero JSON/DB) y los detalles del esquema físico.

## Consecuencias

### Positivas

- Documentar la decisión permitirá avanzar con migraciones, backups y scripts.

### Negativas / Trade-offs

- Elección temprana puede condicionar despliegues y herramientas.

### Riesgos

- Riesgo de re-work si la elección no encaja con requisitos de escalabilidad futuros.

## Alternativas consideradas

| Alternativa | Por qué se descartó (por ahora) |
|-------------|---------------------------------|
| SQLite | Recomendado para v1.0 por simplicidad; pendiente evaluación formal |
| PostgreSQL embebido | Potente pero mayor complejidad operacional |
| Fichero plano/JSON | Simple pero menos transaccional y más frágil |

## Referencias

- `06-data/models.md`
- `15-project-control/technical-backlog.md` (TB-001)

***
