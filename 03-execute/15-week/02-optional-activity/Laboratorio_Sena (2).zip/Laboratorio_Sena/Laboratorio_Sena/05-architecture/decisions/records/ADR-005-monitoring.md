# ADR-005: Monitoreo y métricas mínimas

> Estado: PROPOSED
> Fecha: 2026-07-03
> Autores: Equipo de Arquitectura
> Equipos involucrados: Operaciones, Desarrollo

---

## Contexto

El SRS no define métricas, umbrales o herramientas de monitoreo. Para operaciones y detección temprana de incidentes es necesario acordar un conjunto mínimo de métricas y una herramienta de recolección.

## Decisión

Pendiente de definición por el equipo de arquitectura: métricas mínimas (p.ej. transacciones por hora, errores críticos, espacio en disco), umbrales y herramienta (p.ej. Prometheus+Grafana, solución SaaS, logs locales con exportación).

## Consecuencias

### Positivas

- Definición permitirá crear alertas y dashboards para operaciones.

### Riesgos

- Recolección excesiva de métricas puede aumentar costos y complejidad.

## Alternativas consideradas

| Alternativa | Por qué se descartó (por ahora) |
|-------------|---------------------------------|
| Prometheus+Grafana | Potente para métricas; requiere infraestructura adicional |
| Solución SaaS | Menos mantenimiento pero con costo |
| Logs locales con exportación | Simple inicialmente; menos capacidades de alerta en tiempo real |

## Referencias

- `13-operations/observability.md`
- `15-project-control/maintenance.md`

***
