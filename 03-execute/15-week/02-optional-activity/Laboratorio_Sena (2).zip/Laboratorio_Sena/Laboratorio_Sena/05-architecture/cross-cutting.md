# cross-cutting

> Estado: 🟡 | Última actualización: 2026-04-11
> Autor: Equipo 3

## Propósito

Reunir las preocupaciones transversales que afectan a múltiples capas o módulos: seguridad, logging, copia de seguridad, validación y gestión de errores.

## Módulos transversales propuestos (conceptual)

- Autenticación y autorización
	- Control de acceso por roles (`Administrador`, `Cajero`).
	- Almacenamiento seguro de credenciales (hash); detalles de cifrado y políticas de expiración: Pendiente de definición.

- Logging y auditoría
	- Registro de eventos importantes: `VentaRegistrada`, `RecepcionConfirmada`, `CierreDelDiaGenerado`, intentos de login fallidos.
	- Logs accesibles para el administrador local; rotación/retención: Pendiente de definición.

- Copias de seguridad y persistencia
	- Copia de seguridad automática durante cierre de día (evento `CopiaSeguridadCreada`).
	- Política de ubicaciones y retención: Pendiente de definición.

- Validación y normalización de datos
	- Validaciones de input en UI (productos, cantidades, NIT de proveedor) y reglas de negocio replicadas en la capa de dominio.

- Manejo de errores y transacciones
	- Operaciones críticas (registro de venta + actualización de inventario) deben ejecutarse en transacción atómica a nivel de persistencia. Políticas de retry y rollback: Pendiente de definición.

## Observaciones

- Todos los aspectos transversales se han definido conceptualmente desde el SRS; las decisiones tecnológicas y parámetros concretos deberán registrarse en ADRs antes de la implementación.
