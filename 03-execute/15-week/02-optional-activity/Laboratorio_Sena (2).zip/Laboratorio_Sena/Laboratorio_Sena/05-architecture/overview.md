# overview

> Estado: 🟡 | Última actualización: 2026-04-11
> Autor: Equipo 3

## Propósito

Este documento describe la arquitectura conceptual del "Sistema de Gestión Comercial — Supermercado La Esquina" (SRS v1.0). La arquitectura propuesta se deriva exclusivamente de los requerimientos del SRS y de las consecuencias lógicas de dichos requerimientos para una aplicación de escritorio destinada a un pequeño comercio.

## Resumen ejecutivo

El sistema será una aplicación de escritorio monolítica (versión 1.0) organizada en capas: Presentación (interfaz de punto de venta), Aplicación (casos de uso), Dominio (entidades y reglas), Persistencia (almacenamiento local) y Cross-cutting (autenticación, logging, copia de seguridad). No se introducen servicios externos, microservicios ni despliegues en nube, ya que están fuera del alcance definido por el SRS.

## Principios arquitectónicos

- Mantener simplicidad operativa para un comercio pequeño; priorizar fiabilidad y facilidad de uso.
- Separación clara entre lógica de negocio (dominio) y detalles de persistencia para facilitar mantenimiento.
- Diseñar eventos de dominio (p. ej. `VentaRegistrada`, `InventarioActualizado`) para soporte de auditoría y reportes.
- Proteger accesos mediante control de roles (Administrador, Cajero) y almacenamiento seguro de credenciales.

## Límites y exclusiones

- No se contempla integración con facturación electrónica, pasarelas de pago ni servicios remotos en la versión 1.0 (SRS v1.0). Cualquier integración futura deberá documentarse en ADRs y en `05-architecture/decisions/`.
- Detalles concretos de tecnología (motor de base de datos, framework UI) no están especificados en el SRS: Pendiente de definición por el equipo de arquitectura.
