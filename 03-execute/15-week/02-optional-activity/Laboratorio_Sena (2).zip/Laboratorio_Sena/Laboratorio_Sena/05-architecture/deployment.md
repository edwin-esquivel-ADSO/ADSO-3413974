# deployment

> Estado: 🟡 | Última actualización: 2026-04-11
> Autor: Equipo 3

## Estrategia de despliegue (versión 1.0)

Según el SRS v1.0 la aplicación es de escritorio destinada a operar localmente en el punto de venta. Por tanto la estrategia de despliegue para la versión 1.0 es:

- Instalación local en el equipo del punto de venta (equipo del supermercado).
- Actualizaciones distribuidas manualmente o mediante un instalador local; un mecanismo de actualizaciones automáticas queda pendiente y deberá evaluarse en v1.1.

## Requisitos de entorno

- Sistema operativo soportado: Pendiente de definición por el equipo de arquitectura (SRS no especifica SO).
- Hardware mínimo: Pendiente de definición.

## Backup y recuperación

- Copia de seguridad automática generada durante el cierre de día. Políticas de retención y ubicación de backup deben definirse antes de la entrega.

## Notas de operación

- No se consideran despliegues en nube ni contenedores para la versión 1.0 (fuera del alcance del SRS).
- Cualquier cambio en estrategia de despliegue debe registrarse en un ADR y en esta sección.
