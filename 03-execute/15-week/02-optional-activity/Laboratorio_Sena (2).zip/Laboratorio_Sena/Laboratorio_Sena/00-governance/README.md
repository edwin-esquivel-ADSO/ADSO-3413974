# Gobierno documental

> Estado: 🟢 Estable | Última actualización: 2026-04-11
> Autor: Equipo de Gobernanza

Reglas comunes para que todos los equipos documenten con el mismo criterio, evitando duplicaciones y exposiciones de datos sensibles. Los documentos clave de gobernanza (naming, seguridad, git, ADRs) están definidos y listos para uso.

## Archivos

| Archivo | Descripción | Estado |
|---------|-------------|--------|
| [documentation-rules.md](./documentation-rules.md) | Naming, estructura mínima, estados, índices y diagramas | 🟢 |
| [git-conventions.md](./git-conventions.md) | Ramas, ambientes, releases y commits | 🟢 |
| [microservices-documentation.md](./microservices-documentation.md) | Reglas para documentar microservicios reales | 🟢 |
| [security-rules.md](./security-rules.md) | Reglas contra fugas de información sensible | 🟢 |
| [definition-of-ready.md](./definition-of-ready.md) | Criterios para saber si un documento puede pasar a revisión | 🟢 |
| [definition-of-done.md](./definition-of-done.md) | Criterios para cerrar un documento como estable | 🟢 |

Notas: cambios futuros en gobernanza deben registrarse en `CHANGELOG.md` y aprobarse según el flujo de `definition-of-ready` y `definition-of-done`.
