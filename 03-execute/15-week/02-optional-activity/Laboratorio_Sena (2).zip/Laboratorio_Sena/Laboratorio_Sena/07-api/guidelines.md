# guidelines

> Estado: 🟡 | Última actualización: 2026-04-11
> Autor: Equipo 3

## Propósito

Definir convenciones y buenas prácticas para cualquier API relacionada con el sistema, tomando el SRS v1.0 como fuente de verdad.

## Principios de diseño

- APIs RESTful basadas en recursos: `/productos`, `/ventas`, `/proveedores`, `/pedidos`, `/usuarios`.
- Versionado en la ruta: incluir versión mayor en la ruta `/v1/`.
- Usar verbos HTTP semánticos: GET (lectura), POST (crear), PUT/PATCH (actualizar), DELETE (eliminar — si aplica).
- Formato de intercambio: JSON con `Content-Type: application/json`.
- Manejo de errores: estructura uniforme `{ "code": "ERR_CODE", "message": "Descripción", "details": {...} }`.
- Paginación para colecciones grandes: parámetros `page` y `pageSize` o `limit`/`offset`.
- Autorización mediante roles y scopes; detalles concretos de token/cifra: Pendiente de definición por el equipo de arquitectura.

## Recursos sugeridos (endpoints básicos)

- `GET /v1/productos` — Listar productos
- `GET /v1/productos/{id}` — Obtener producto
- `POST /v1/ventas` — Registrar venta
- `GET /v1/ventas/{id}` — Obtener venta
- `POST /v1/pedidos` — Crear pedido a proveedor
- `GET /v1/proveedores` — Listar proveedores

## Contratos y compatibilidad

- Los contratos OpenAPI aprobados se ubicarán en `07-api/contracts/openapi/`.
- Cualquier cambio incompatible en un contrato debe versionarse como `v2` y comunicarse a los consumidores.

## Observaciones

- El SRS describe la necesidad de soporte para reportes y auditoría, pero no especifica APIs públicas: estas reglas aplican tanto para APIs locales como para futuras integraciones remotas.
