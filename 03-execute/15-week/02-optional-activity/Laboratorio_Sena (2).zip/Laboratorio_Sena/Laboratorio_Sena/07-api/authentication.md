# authentication

> Estado: 🟡 | Última actualización: 2026-04-11
> Autor: Equipo 3

## Propósito

Describir la estrategia de autenticación y autorización para acceder a APIs o funcionalidades expuestas por el sistema.

## Modelo conceptual

- El SRS define roles de `Administrador` y `Cajero`. El control de acceso debe basarse en RBAC (Role-Based Access Control).
- Para llamadas internas o futuras APIs remotas, se recomienda encapsular permisos en scopes asociados a los roles.

## Opciones técnicas (a evaluar)

- Autenticación local: credenciales almacenadas con hash seguro (bcrypt/argon2) y validación en el host local.
- APIs remotas: usar tokens firmados (JWT) o tokens opacos emitidos por un servicio de autenticación; detalles de firma, expiración y rotación: Pendiente de definición por el equipo de arquitectura.

## Reglas derivadas del SRS

- Nunca almacenar contraseñas en texto plano — siempre usar hash con salt.
- Registrar intentos de acceso fallidos en logs para auditoría.

## Observaciones

- El SRS no especifica un proveedor de identidad ni un método de tokens; por tanto la elección entre JWT, OAuth2 o mecanismos personalizados queda pendiente.
