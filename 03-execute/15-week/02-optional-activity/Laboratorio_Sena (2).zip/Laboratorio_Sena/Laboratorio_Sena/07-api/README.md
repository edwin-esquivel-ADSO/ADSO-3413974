# API

> Estado: 🟡 | Última actualización: 2026-04-11
> Autor: Equipo 3

## Contenido

Define lineamientos de API, autenticación y ubicación de contratos OpenAPI. El SRS v1.0 no exige APIs públicas para la versión 1.0 (aplicación de escritorio), pero esta sección prepara el terreno para integraciones futuras respetando la trazabilidad del SRS.

## Archivos

| Archivo | Descripción | Estado |
|---------|-------------|--------|
| [guidelines.md](./guidelines.md) | Convenciones de diseño de APIs | 🟡 |
| [authentication.md](./authentication.md) | Estrategia de autenticación y autorización | 🟡 |
| [contracts/openapi/](./contracts/openapi/) | Contratos OpenAPI validados y publicables | 🟡 |

## Dónde va cada contrato

| Tipo de contrato | Dónde vive | Cuándo se usa |
|-----------------|------------|---------------|
| Contrato de implementación (borrador, en evolución) | `09-microservices/services/<svc>/api-contract.md` | Durante el desarrollo del servicio |
| Contrato OpenAPI publicable (estable, revisado) | `07-api/contracts/openapi/<svc>.yaml` | Cuando el contrato es estable y puede compartirse con consumidores externos |

**Regla:** el contrato en `07-api/contracts/openapi/` es la versión aprobada por arquitectura. Si hay diferencia entre ambos, el de `07-api/` tiene precedencia para consumidores externos.

## Observación

- Para la versión 1.0 la prioridad es la aplicación de escritorio; las APIs solo se definen aquí para garantizar que, si se requieren integraciones, haya reglas y un lugar único para los contratos.
