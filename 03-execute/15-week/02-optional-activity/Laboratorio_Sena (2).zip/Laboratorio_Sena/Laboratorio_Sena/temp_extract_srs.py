import zipfile, re
p = r'C:\Users\esqui\OneDrive\Desktop\TRABAJOS EN CLASE 2026\Junio\20\SRS_MercaGO_TiendalaEsquina_v1.0_safe.docx'
with zipfile.ZipFile(p) as z:
    xml = z.read('word/document.xml').decode('utf-8')
texts = re.findall(r'<w:t[^>]*>(.*?)</w:t>', xml)
print(''.join(texts)[:20000])
