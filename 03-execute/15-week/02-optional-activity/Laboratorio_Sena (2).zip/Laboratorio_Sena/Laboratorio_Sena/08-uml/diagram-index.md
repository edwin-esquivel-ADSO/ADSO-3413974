# Índice de diagramas

| Diagrama | Tipo | Archivo fuente | Exportación | Estado |
|----------|------|---------------|-------------|--------|
| Mapa de contextos | Componentes | diagrams/source/context-map-component.wsd | diagrams/exports/context-map-component.svg | 🟡 |
| Clases de dominio | Clases | diagrams/source/domain-class.wsd | diagrams/exports/domain-class.svg | 🟡 |
| Secuencia de venta | Secuencia | diagrams/source/venta-sequence.wsd | diagrams/exports/venta-sequence.svg | 🟡 |
| Despliegue local | Despliegue | diagrams/source/deployment.wsd | diagrams/exports/deployment.svg | 🟡 |
