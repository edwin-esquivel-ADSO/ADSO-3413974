# UML

> Estado: 🟡 | Última actualización: 2026-04-11
> Autor: Equipo 3

Repositorio de diagramas UML y arquitectura visual alineados con el SRS v1.0. Todo diagrama debe incluir la fuente editable y una exportación revisada.

## Convenciones

- Fuentes en `diagrams/source/` con extensión `.wsd` o `.puml`
- Exportaciones en `diagrams/exports/` con formato `.svg` preferido
- Nombre de archivo: `<dominio>-<tipo>.<ext>` (ej: `venta-sequence.wsd`)
- Todo diagrama debe registrarse en [diagram-index.md](./diagram-index.md)

## Diagrama recomendados (iniciales)

- Mapa de contextos / componentes (`context-map-component.wsd`) — muestra bounded contexts: Ventas, Inventario, Proveedores, Reportes, Seguridad.
- Diagrama de clases de dominio (`domain-class.wsd`) — principales entidades: Producto, Venta, Pedido, Proveedor, Usuario.
- Secuencia de venta (`venta-sequence.wsd`) — flujo desde registro de venta hasta actualización de inventario y generación de cierre de día.
- Diagrama de despliegue (`deployment.wsd`) — topología local (puesto de venta, almacenamiento local, opcional backup externo).

## Archivos

| Archivo | Descripción | Estado |
|---------|-------------|--------|
| [diagram-index.md](./diagram-index.md) | Índice de fuentes y exportaciones de diagramas | 🟡 |
| [diagrams/source/](./diagrams/source/) | Fuentes editables de diagramas | 🟡 |
| [diagrams/exports/](./diagrams/exports/) | Exportaciones SVG o PNG | 🟡 |

Notas: los diagramas listados se derivan del SRS; los detalles de contenido de cada diagrama (niveles de detalle, notación exacta) quedan pendientes de definición por el equipo de arquitectura.
