# data-dictionary

> Estado: 🟡 | Última actualización: 2026-04-11
> Autor: Equipo 3

Este diccionario documenta, a nivel conceptual, las principales entidades y campos derivados del SRS v1.0. Los tipos concretos y longitudes quedan pendientes.

| Entidad | Campo | Descripción | Observaciones |
|--------|-------|-------------|---------------|
| Producto | productoId | Identificador único del producto | PK (UUID o int) |
| Producto | codigo | Código interno/etiqueta | Único por producto |
| Producto | nombre | Nombre comercial del producto | |
| Producto | descripcion | Texto descriptivo (opcional) | |
| Producto | precioVenta | Precio de venta unitario | >= 0 |
| Producto | stockActual | Cantidad disponible | >= 0 |
| Producto | stockMinimo | Umbral mínimo para alertas | |
| Venta | ventaId | Identificador de la transacción | PK |
| Venta | fechaHora | Fecha y hora de la venta | |
| Venta | total | Total de la venta | Calculado: sum(subtotales) |
| Venta | idCajero | FK a `Usuario` que registró la venta | |
| VentaItem | ventaItemId | Identificador del ítem | PK |
| VentaItem | ventaId | FK a `Venta` | |
| VentaItem | productoId | FK a `Producto` | |
| VentaItem | cantidad | Cantidad vendida | > 0 |
| VentaItem | precioUnitario | Precio aplicado | |
| VentaItem | subtotal | cantidad * precioUnitario | |
| Proveedor | proveedorId | Identificador único | PK |
| Proveedor | nombre | Nombre del proveedor | Detección duplicados por NIT o nombre |
| Proveedor | nit | Identificación fiscal | Único recomendado |
| Proveedor | telefono | Teléfono de contacto | |
| Proveedor | email | Correo electrónico | |
| Pedido | pedidoId | Identificador del pedido | PK |
| Pedido | proveedorId | FK a `Proveedor` | |
| Pedido | fechaCreacion | Fecha de creación del pedido | |
| Pedido | fechaEsperada | Fecha estimada de entrega | |
| Pedido | estado | Pendiente / Recibido / Cancelado | |
| PedidoItem | pedidoItemId | Identificador del item del pedido | PK |
| PedidoItem | pedidoId | FK a `Pedido` | |
| PedidoItem | productoId | FK a `Producto` | |
| PedidoItem | cantidadSolicitada | Cantidad solicitada | |
| PedidoItem | cantidadRecibida | Cantidad recepcionada | Opcional; se actualiza al recibir mercancía |
| Usuario | usuarioId | Identificador del usuario | PK |
| Usuario | nombre | Nombre completo | |
| Usuario | usuario | Nombre de usuario para login | Único |
| Usuario | hashPassword | Hash de la contraseña | Nunca almacenar texto plano |
| Usuario | rol | Administrador / Cajero | Define permisos |

## Observaciones

- Campos adicionales (direcciones, IVA, categorías de productos) no están especificados en el SRS: Pendiente de definición.
- Especificar tipos concretos, tamaños y restricciones (NOT NULL, FK ON DELETE/UPDATE) durante el diseño de la base de datos.
