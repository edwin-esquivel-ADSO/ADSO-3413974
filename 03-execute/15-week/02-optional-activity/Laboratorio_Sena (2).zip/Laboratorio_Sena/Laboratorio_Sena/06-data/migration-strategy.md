# migration-strategy

> Estado: 🟡 | Última actualización: 2026-04-11
> Autor: Equipo 3

## Objetivo

Describir la estrategia para evolucionar el esquema de datos del sistema manteniendo la integridad y posibilitando reversión en caso de fallo. La estrategia propuesta se ajusta al alcance local (aplicación de escritorio) del SRS v1.0.

## Principios

- Versionado de esquema: mantener un `schema_version` en la base de datos y aplicar migraciones numeradas.
- Migraciones idempotentes y reversibles cuando sea posible.
- Respaldos automáticos previos a migraciones mayores (crear copia de seguridad local antes de aplicar cambios).

## Proceso sugerido

1. Antes de aplicar migración en entorno productivo: generar copia de seguridad completa (evento `CopiaSeguridadCreada`).
2. Ejecutar migración numerada (script SQL o herramienta de migración).
3. Verificar integridad y pruebas de humo (consultas básicas: número de ventas, productos, integridad de FK).
4. Si falla, ejecutar script de reversión o restaurar desde backup.

## Herramientas y formatos

- Elección de herramienta de migración (Flyway, Alembic, Liquibase, o scripts SQL manuales) queda pendiente y debe registrarse en un ADR.

## Consideraciones para migraciones locales

- Debido a la naturaleza de despliegue local, el mecanismo de actualización debe ser simple: instalador que aplica migraciones o asistente de actualización que realiza backup y aplica scripts.
- Documentar claramente pasos de recuperación para el comerciante (restaurar backup, contacto de soporte).

## Observaciones

- Políticas concretas de retención de backups, ubicación (disco local vs red) y periodicidad no están especificadas en el SRS: Pendiente de definición.
