# models

> Estado: 🟡 | Última actualización: 2026-04-11
> Autor: Equipo 3

## Propósito

Documentar el modelo de datos conceptual/lógico para la versión 1.0 del Sistema de Gestión Comercial — Supermercado La Esquina (SRS v1.0). Esta sección es orientativa y evita entrar en detalles físicos específicos (motor, tipos exactos), los cuales quedan pendientes.

## Entidades principales (modelo conceptual)

- `Producto`
	- Clave natural: `productoId` (UUID o entero auto-incremental).
	- Atributos: `codigo`, `nombre`, `descripcion`, `precioVenta`, `stockActual`, `stockMinimo`.

- `Venta`
	- Clave: `ventaId`.
	- Atributos: `fechaHora`, `total`, `idCajero`, `medioPago` (opcional), `estado` (Confirmada).
	- Relación: 1 `Venta` — N `VentaItem`.

- `VentaItem`
	- Atributos: `ventaItemId`, `ventaId` (FK), `productoId` (FK), `cantidad`, `precioUnitario`, `subtotal`.

- `Proveedor`
	- Clave: `proveedorId`.
	- Atributos: `nombre`, `nit`, `telefono`, `email`, `condicionesPago`.

- `Pedido`
	- Clave: `pedidoId`.
	- Atributos: `proveedorId` (FK), `fechaCreacion`, `fechaEsperada`, `estado` (Pendiente|Recibido|Cancelado).
	- Relación: 1 `Pedido` — N `PedidoItem`.

- `PedidoItem`
	- Atributos: `pedidoItemId`, `pedidoId` (FK), `productoId` (FK), `cantidadSolicitada`, `cantidadRecibida` (opcional).

- `Usuario`
	- Clave: `usuarioId`.
	- Atributos: `nombre`, `usuario` (login), `hashPassword`, `rol` (Administrador|Cajero), `ultimoAcceso`.

## Notas sobre modelos físicos

- Tipos concretos (VARCHAR lengths, precisiones numéricas, elección entre UUID o int) no están especificados en el SRS: Pendiente de definición por el equipo de arquitectura.
- Índices: índices esperados en `productoId`, `ventaId`, `fechaHora`, `proveedorId` para consultas de ventas e inventario.
- Transacciones: las operaciones que afectan `Venta` y `Producto.stockActual` deben realizarse en una transacción atómica.
