import re
text=open('srs_text.txt',encoding='utf-8').read()
rf=re.findall(r'RF-\d+[:\)]?\s*[-–:]?\s*(.*?)((?=RF-\d+[:\)]?)|(?=CU-\d+)|(?=\Z))', text, flags=re.S)
cu=re.findall(r'CU-\d+[:\)]?\s*[-–:]?\s*(.*?)((?=CU-\d+)|(?=RF-\d+)|(?=\Z))', text, flags=re.S)
nf=re.findall(r'No funcional(?:es)?[:\)]?\s*(.*?)((?=\n\n)|(?=\Z))', text, flags=re.I|re.S)
rf_lines = re.findall(r'RF-\d+[^\n]*', text)
cu_lines = re.findall(r'CU-\d+[^\n]*', text)
open('extracted_reqs.txt','w',encoding='utf-8').write('RF detailed:\n'+str(rf[:10])+'\n\nCU detailed:\n'+str(cu[:10])+'\n\nRF lines:\n' + '\n'.join(rf_lines[:200]) + '\n\nCU lines:\n' + '\n'.join(cu_lines[:200]) + '\n\nNF matches:\n' + '\n'.join([m[0] for m in nf[:20]]))
print('done')
