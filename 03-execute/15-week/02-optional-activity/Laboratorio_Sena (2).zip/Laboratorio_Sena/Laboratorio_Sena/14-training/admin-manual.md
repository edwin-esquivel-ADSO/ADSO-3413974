# Admin Manual (operaciones y soporte)

> Estado: � | Última actualización: 2026-07-03
> Autor: Equipo de Operaciones

## Introducción

Manual para administradores de tienda y responsables de soporte: gestión de usuarios, copias de seguridad, ajustes de inventario, proveedores y resolución de incidentes.

## Gestión de usuarios

- Crear usuario desde el módulo `Administración` o `Usuarios`.
- Asignar rol `Cajero` o `Administrador` según responsabilidad.
- Resetear contraseña cuando un usuario no pueda ingresar.
- Verificar que el usuario tenga permisos adecuados para anular ventas, modificar inventario o ver reportes.

## Inventario y proveedores

- Registrar productos nuevos con nombre, código, precio y cantidad inicial.
- Ajustar `stockActual` cuando se recibe mercancía o se corrige un conteo.
- Gestionar proveedores desde el módulo `Proveedores`:
  - Crear proveedor con datos de contacto.
  - Registrar pedidos y asociarlos a la recepción de mercancía.

## Copias de seguridad y restauración

- Realizar backup de la base de datos al final del día de cierre.
- Seguir el procedimiento documentado en `13-operations/backup-and-recovery.md`.
- Verificar la consistencia de la restauración antes de poner el sistema operativo nuevamente.

## Reportes y cierre de día

- Revisar reportes de ventas diarias, ventas por producto y rentabilidad.
- Confirmar que los datos del día coincidan con el efectivo en caja.
- Generar informes básicos para toma de decisiones.

## Soporte y escalamiento

- Resolver primero los incidentes de operación local.
- Escalar problemas de integridad de datos, fallas críticas o seguridad al equipo de arquitectura.
- Usar `13-operations/incident-management.md` para clasificar incidentes.

## Observaciones

- Detalles de contactos de soporte, horarios de formación y material multimedia no están disponibles en el SRS.
- Cualquier procedimiento operativo adicional debe documentarse de forma separada.
