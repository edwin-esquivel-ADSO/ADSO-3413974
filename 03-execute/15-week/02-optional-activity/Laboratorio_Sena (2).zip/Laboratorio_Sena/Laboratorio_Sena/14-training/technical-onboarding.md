# Technical Onboarding

> Estado: � | Última actualización: 2026-07-03
> Autor: Equipo de Desarrollo

## Objetivo

Proveer al nuevo integrante técnico con la información mínima para configurar el entorno local, entender la arquitectura y contribuir al proyecto.

## Pasos iniciales

1. Clonar el repositorio.
2. Activar el entorno virtual: `.
   .venv\Scripts\Activate.ps1` en PowerShell.
3. Revisar `README.md` raíz y `05-architecture/overview.md` para comprender la arquitectura general.
4. Revisar `srs_text.txt` para conocer la fuente de verdad del proyecto.
5. Ejecutar pruebas básicas con `pytest`.

## Entorno y documentos clave

- Archivo base del SRS: `srs_text.txt`.
- Documentación de dominio y datos: `02-domain/`, `06-data/`.
- Guía de constraints y calidad: `11-quality/testing-strategy.md`.
- Documentos de operaciones y soporte: `13-operations/`, `14-training/`.

## Qué verificar primero

- Configuración local de Python y dependencias.
- Archivos de documentación críticos: `00-governance/`, `04-requirements/`, `05-architecture/`.
- Scripts existentes en la raíz: `extract_requirements.py`, `inspect_srs.py`.

## Observaciones

- Las credenciales de despliegue y servicios externos no están en el SRS.
- Los detalles de herramientas específicas (base de datos, UI, CI/CD) quedan como `Pendiente de definición por el equipo de arquitectura`.
