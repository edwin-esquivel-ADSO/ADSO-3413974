# Entrenamiento

> Estado: � | Última actualización: 2026-07-03
> Autor: Equipo de Entrenamiento

Contiene manuales y material de onboarding derivados del SRS v1.0. El enfoque principal es capacitar a cajeros y al personal de tienda para operar el sistema y al equipo técnico para mantenerlo.

## Audiencias

| Audiencia | Documento principal | Quién lo escribe |
|-----------|--------------------|--------------------|
| Usuarios finales (cajeros) | `user-manual.md` | Equipo de producto / soporte |
| Administradores del sistema (tienda) | `admin-manual.md` | Equipo de operaciones |
| Nuevos integrantes técnicos del proyecto | `technical-onboarding.md` | Equipo de desarrollo / DevOps |

## Archivos

| Archivo | Descripción | Estado |
|---------|-------------|--------|
| [user-manual.md](./user-manual.md) | Manual para usuarios finales | � |
| [admin-manual.md](./admin-manual.md) | Manual para administración y soporte | 🟢 |
| [technical-onboarding.md](./technical-onboarding.md) | Guía de entrada para integrantes técnicos | 🟢 |

Notas: el material de formación debe incluir guías paso a paso para operaciones críticas (registro de ventas, recepción de pedidos, copia de seguridad y restauración). Contenidos como horarios de formación y materiales multimedia quedan fuera del SRS y deben definirse por el equipo de formación.
