# User Manual (operador / cajero)

> Estado: � | Última actualización: 2026-07-03
> Autor: Equipo de Producto / Soporte

## Introducción

Guía para registrar ventas, administrar cobros y consultar inventario en el sistema del Supermercado La Esquina.

## Iniciar sesión

- Abrir la aplicación de escritorio.
- Ingresar el usuario y la contraseña asignados.
- Si falla el acceso, contactar al administrador de la tienda.

## Registrar una venta

1. Buscar el producto por código o nombre.
2. Seleccionar la cantidad vendida y agregar al carrito.
3. Revisar el subtotal, descuentos y total.
4. Confirmar el medio de pago.
5. Presionar `Cobrar` o `Finalizar`.
6. Entregar el comprobante impreso o mostrar la confirmación en pantalla.

## Gestión de cobro y cambio

- El sistema calcula automáticamente el total y el cambio.
- En caso de error, anular la venta antes de cerrar el registro y repetir el proceso.

## Anular una venta

- Solo usuarios con rol `Administrador` pueden anular ventas.
- Ir a `Reportes` o `Historial de ventas`, buscar por `ventaId` o fecha, y seleccionar `Anular`.
- Verificar que el inventario y el efectivo se ajusten correctamente.

## Inventario y alertas

- Consultar `Inventario` para ver `stockActual` y los productos con `StockMinimoAlcanzado`.
- Reportar a administración cualquier producto agotado para solicitar reposición.

## Reportes básicos

- Consultar ventas diarias y estadísticas desde el módulo `Reportes`.
- Usar los filtros por fecha para ver las ventas del turno o del día.

## Buenas prácticas

- Registrar cada venta inmediatamente después del pago.
- No procesar cobros en papel simultáneamente con el sistema.
- Revisar alertas de inventario antes de cerrar el día.

## Observaciones

- Los nombres exactos de botones y pantallas pueden variar según la implementación UI.
- Si algún detalle no está definido en el SRS, se mantiene como `Pendiente de definición por el equipo de arquitectura`.
