# Contexto

> Estado: 🟡 | Última actualización: 2026-04-11
> Autor: Equipo 3

## Contenido

Carpeta que centraliza el contexto del proyecto "Sistema de Gestión Comercial — Supermercado La Esquina": descripción del negocio, problema central, objetivos, alcance y glosario de términos del dominio.

## Archivos

| Archivo | Descripción | Estado |
|---------|-------------|--------|
| [overview.md](./overview.md) | Contexto institucional, problema y objetivos generales (basado en SRS v1.0) | 🟡 |
| [scope.md](./scope.md) | Alcance, exclusiones, supuestos y restricciones (basado en SRS v1.0) | 🟡 |
| [glossary.md](./glossary.md) | Glosario del dominio adaptado del SRS | 🟡 |

La información en esta carpeta se deriva únicamente del SRS (fuente de verdad). Para elementos no especificados en el SRS se ha marcado "Pendiente de definición por el equipo de arquitectura." No se han añadido funcionalidades fuera del alcance definido por el SRS.
