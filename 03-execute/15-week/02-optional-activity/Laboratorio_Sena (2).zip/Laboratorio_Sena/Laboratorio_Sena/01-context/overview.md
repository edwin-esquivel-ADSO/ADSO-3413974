# Overview

> Estado: 🟡 | Última actualización: 2026-04-11
> Autor: Equipo 3 (Esneider Covaleda, Julián Camargo, Edwin Esquivel, Jaminton Peña)

## Contexto institucional

El presente repositorio documenta el Sistema de Gestión Comercial para el "Supermercado La Esquina", un establecimiento de comercio minorista de barrio administrado por Don Carlos R. y su esposa Doña Martha R. El local opera de lunes a domingo, atiende entre 40 y 60 clientes diarios y maneja un catálogo aproximado de 90 productos de consumo masivo (alimentos, aseo y bebidas). Al inicio del proyecto, las operaciones se realizaban de forma manual con cuaderno y calculadora.

## Problema

El negocio presenta ineficiencias operativas y riesgo económico por la ausencia de automatización: cálculo manual de ventas (3–4.5 minutos por cliente), errores de cobro y cambio, ausencia de control de inventario en tiempo real, gestión informal de proveedores y falta de reportes para la toma de decisiones.

## Objetivo general

Desarrollar un sistema de escritorio que automatice ventas, control de inventario y gestión de proveedores para reducir errores operativos, optimizar el tiempo de atención y proveer información oportuna al administrador.

## Alcance (resumen)

Versión 1.0 (MVP): registro y consulta de ventas; control de inventario con actualización automática y alertas de stock mínimo; registro y consulta de proveedores e historial de pedidos; reportes básicos (diarios y mensuales); autenticación y control de acceso con roles (administrador, cajero).

## Referencia (fuente de verdad)

Especificación de Requisitos de Software (SRS) — "Sistema de Gestión Comercial — Supermercado La Esquina". Versión 1.0, 11-abr-2026.
