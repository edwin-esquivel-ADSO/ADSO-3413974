# Alcance

> Estado: 🟡 | Última actualización: 2026-04-11
> Autor: Equipo 3 (ver Overview)

## En alcance

- Registro y consulta de ventas con cálculo automático de totales y cambio.
- Control de inventario con actualización automática al registrar ventas y alertas de stock mínimo.
- Registro y consulta de proveedores y gestión de pedidos (historial de pedidos, estados).
- Reportes básicos: cierre de día, ventas diarias y mensuales, top productos, productos agotados.
- Autenticación y control de acceso por roles: administrador y cajero.

## Fuera de alcance (versión 1.0)

- Facturación electrónica (DIAN).
- Integración con datáfono o pasarelas de pago.
- Aplicación móvil o versión web.
- Programas de fidelización o gestión avanzada de clientes.

## Supuestos

- El negocio operará como un punto de venta local con ~90 productos y 40–60 clientes diarios.
- El personal base: administrador (propietario), cajero(a) y empleado de bodega.
- La versión 1.0 es un producto de escritorio para uso local en el punto de venta.

## Restricciones

- No se integrará con servicios externos en la versión 1.0 (pagos, facturación, nube) salvo que el SRS lo indique en versiones futuras.
- Requisitos de rendimiento y escalabilidad se limitarán al tamaño operativo descrito en el SRS (pequeño comercio). Para aspectos no especificados: Pendiente de definición por el equipo de arquitectura.