# Glosario

> Estado: 🟡 | Última actualización: 2026-04-11
> Autor: Equipo 3

| Término | Definición | Contexto |
|---------|------------|----------|
| Administrador | Usuario con permisos completos del sistema; responsable de configuración, cierre de día y consulta de reportes. (Ej.: Don Carlos R.) | Roles del negocio |
| Cajero | Usuario encargado de registrar ventas y procesar cobros en el punto de venta. | Roles del negocio |
| Empleado de bodega | Personal responsable de la recepción de mercancía y actualización de stock. | Roles del negocio |
| Producto | Artículo en el catálogo del supermercado, identificado por código, nombre y precio. | Dominio de producto |
| Inventario | Registro del stock disponible de productos; se actualiza al registrar ventas o recepciones de pedido. | Operaciones |
| Venta | Transacción comercial que registra uno o varios productos, cantidad, precio, total y forma de pago. | Operaciones |
| Proveedor | Entidad que suministra productos al supermercado; mantiene datos de contacto y condiciones de suministro. | Operaciones |
| Pedido | Solicitud de abastecimiento a un proveedor con productos, cantidades y fecha de entrega; maneja estados (Pendiente, Recibido). | Operaciones |
| Reporte | Documento generado por el sistema que sintetiza información operativa (ventas, top productos, productos agotados, saldo de caja esperado). | Informes |
| Autenticación | Mecanismo para identificar usuarios antes de permitir acceso al sistema. | Seguridad |
| Control de acceso (Roles) | Definición de permisos por rol (Administrador, Cajero). | Seguridad |
