import re
text = open('srs_text.txt', encoding='utf-8').read()
heads = [
    '1\\. Introduccion',
    '1\\.1 Descripcion del negocio',
    '1\\.2 Problema central',
    '1\\.3 Objetivo general del sistema',
    '1\\.4 Alcance del sistema',
    '2\\. Requisitos del sistema',
    '3\\. Casos de uso',
    '4\\. Modelos',
    '5\\. Referencias',
    'Glosario',
    'Definiciones'
]
for h in heads:
    print(h, 'found' if re.search(h, text) else 'missing')

for h in ['1\\.1 Descripcion del negocio','1\\.2 Problema central','1\\.3 Objetivo general del sistema','1\\.4 Alcance del sistema','3\\. Casos de uso','Glosario']:
    m = re.search(h, text)
    if m:
        start = m.start()
        suffix = text[start: start+5000]
        print('\n---\n', h)
        print(suffix)
